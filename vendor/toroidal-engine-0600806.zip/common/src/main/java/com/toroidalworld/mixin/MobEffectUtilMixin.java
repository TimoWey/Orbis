package com.toroidalworld.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

import com.toroidalworld.InjectionTargets;
import com.toroidalworld.engine.seam.SeamRange;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;

import net.minecraft.core.Position;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectUtil;
import net.minecraft.world.phys.Vec3;

@Mixin(MobEffectUtil.class)
public class MobEffectUtilMixin {
    @WrapOperation(
            method = "lambda$addEffectToPlayersAround$0",
            at = @At(value = "INVOKE",
                    target = InjectionTargets.VEC3_CLOSER_THAN))
    private static boolean toroidal$effectRadiusThroughSeam(Vec3 origin, Position playerPosition, double radius,
            Operation<Boolean> original, @Local(argsOnly = true) ServerPlayer player) {
        return SeamRange.closerThan(player, origin, playerPosition, radius);
    }
}
