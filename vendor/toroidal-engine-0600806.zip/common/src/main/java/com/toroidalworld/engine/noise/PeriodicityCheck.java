package com.toroidalworld.engine.noise;

import java.util.LinkedHashSet;
import java.util.Locale;
import java.util.Set;

import org.slf4j.Logger;

import com.toroidalworld.accessors.PeriodicityMark;
import com.toroidalworld.core.ShapedChunkGenerator;
import com.toroidalworld.core.WorldFold;
import com.mojang.logging.LogUtils;

import net.minecraft.core.Direction;
import net.minecraft.core.Holder;
import net.minecraft.core.QuartPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.LevelHeightAccessor;
import net.minecraft.world.level.NoiseColumn;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.biome.BiomeResolver;
import net.minecraft.world.level.biome.Climate;
import net.minecraft.world.level.chunk.ChunkGenerator;
import net.minecraft.world.level.levelgen.RandomState;
import net.minecraft.world.level.levelgen.densityfunction.SamplerContext;

public final class PeriodicityCheck {
    private static final Logger LOGGER = LogUtils.getLogger();

    private static final int[] SAMPLE_X = {0, 100, 255};
    private static final int[] SAMPLE_Z = {0, 137, -211};

    private static final int SAMPLE_Y = 64;

    public static void runOnce(ServerLevel level, WorldFold transformer) {
        if (!((PeriodicityMark) level).toroidal$claimPeriodicityCheck()) {
            return;
        }

        String levelName = level.dimension().identifier().toString();

        ChunkGenerator generator = level.getChunkSource().getGenerator();
        if (!ShapedChunkGenerator.tilesAtSeam(generator)) {
            LOGGER.info("[world-loop] periodicity_skipped level={} generator={}",
                    levelName, generator.getClass().getSimpleName());
            return;
        }

        RandomState randomState = level.getChunkSource().randomState();
        Climate.Sampler sampler = randomState.createClimateSampler(SamplerContext.EMPTY_UNCACHED);
        BiomeResolver biomes = generator.getBiomeSource().createResolver(sampler);
        Direction.Axis lapAxis = transformer.bounds().loops(Direction.Axis.X) ? Direction.Axis.X : Direction.Axis.Z;
        int widthBlocks = transformer.blockDomain(lapAxis).domainLength;
        String axisName = lapAxis.getName().toUpperCase(Locale.ROOT);

        Set<String> brokenFields = new LinkedHashSet<>();
        int brokenSamples = 0;

        for (int z : SAMPLE_Z) {
            for (int x : SAMPLE_X) {
                int xLapAway = lapAxis == Direction.Axis.X ? x + widthBlocks : x;
                int zLapAway = lapAxis == Direction.Axis.Z ? z + widthBlocks : z;
                NoiseColumn columnHere = generator.getBaseColumn(x, z, level, randomState);
                NoiseColumn columnLapAway = generator.getBaseColumn(xLapAway, zLapAway, level, randomState);
                boolean broken = collectColumn(brokenFields, level, columnHere, columnLapAway);

                int quartX = QuartPos.fromBlock(x);
                int quartZ = QuartPos.fromBlock(z);
                int quartY = QuartPos.fromBlock(SAMPLE_Y);
                int lapAwayQuartX = QuartPos.fromBlock(xLapAway);
                int lapAwayQuartZ = QuartPos.fromBlock(zLapAway);

                Climate.TargetPoint climateHere = GenerationTransformerContext.withTransformer(transformer,
                        () -> sampler.sample(quartX, quartY, quartZ));
                Climate.TargetPoint climateLapAway = GenerationTransformerContext.withTransformer(transformer,
                        () -> sampler.sample(lapAwayQuartX, quartY, lapAwayQuartZ));
                broken |= collectClimate(brokenFields, climateHere, climateLapAway);

                Holder<Biome> biomeHere = GenerationTransformerContext.withTransformer(transformer,
                        () -> biomes.getNoiseBiome(quartX, quartY, quartZ));
                Holder<Biome> biomeLapAway = GenerationTransformerContext.withTransformer(transformer,
                        () -> biomes.getNoiseBiome(lapAwayQuartX, quartY, lapAwayQuartZ));
                if (!biomeHere.equals(biomeLapAway)) {
                    brokenFields.add("biome");
                    broken = true;
                }

                if (broken) {
                    brokenSamples++;
                }
            }
        }

        int samples = SAMPLE_X.length * SAMPLE_Z.length;
        if (brokenFields.isEmpty()) {
            LOGGER.info("[world-loop] periodicity_ok level={} axis={} width_blocks={} samples={}",
                    levelName, axisName, widthBlocks, samples);
            return;
        }

        LOGGER.warn(
                "[world-loop] periodicity_broken level={} axis={} width_blocks={} fields={} broken_samples={} samples={}",
                levelName, axisName, widthBlocks, String.join(",", brokenFields), brokenSamples, samples);
    }

    private static boolean collectColumn(Set<String> brokenFields, LevelHeightAccessor heightAccessor,
            NoiseColumn here, NoiseColumn lapAway) {
        for (int y = heightAccessor.getMinY(); y <= heightAccessor.getMaxY(); y++) {
            if (here.getBlock(y) != lapAway.getBlock(y)) {
                brokenFields.add("column");
                return true;
            }
        }

        return false;
    }

    private static boolean collectClimate(Set<String> brokenFields, Climate.TargetPoint here,
            Climate.TargetPoint lapAway) {
        boolean broken = collect(brokenFields, "temperature", here.temperature(), lapAway.temperature());
        broken |= collect(brokenFields, "humidity", here.humidity(), lapAway.humidity());
        broken |= collect(brokenFields, "continentalness", here.continentalness(), lapAway.continentalness());
        broken |= collect(brokenFields, "erosion", here.erosion(), lapAway.erosion());
        broken |= collect(brokenFields, "depth", here.depth(), lapAway.depth());
        return broken | collect(brokenFields, "weirdness", here.weirdness(), lapAway.weirdness());
    }

    private static boolean collect(Set<String> brokenFields, String field, long here, long lapAway) {
        if (here == lapAway) {
            return false;
        }

        brokenFields.add(field);
        return true;
    }

    private PeriodicityCheck() {
    }
}
