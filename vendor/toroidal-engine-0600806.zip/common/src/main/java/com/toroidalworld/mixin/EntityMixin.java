package com.toroidalworld.mixin;

import java.util.Optional;
import java.util.Set;

import org.jspecify.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import com.toroidalworld.accessors.TransformerSource;
import com.toroidalworld.core.WorldFold;
import com.toroidalworld.core.WorldLoopAttachments;
import com.toroidalworld.engine.fold.NearestCopy;
import com.toroidalworld.engine.seam.ClientPosition;
import com.toroidalworld.engine.seam.SeamAim;
import com.toroidalworld.engine.seam.SeamSteering;
import com.toroidalworld.engine.seam.VehicleDismountResync;
import com.toroidalworld.engine.seam.circumnavigation.CircumnavigationTracker;
import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import com.llamalad7.mixinextras.injector.wrapmethod.WrapMethod;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.BlockUtil;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.PositionMoveRotation;
import net.minecraft.world.entity.Relative;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

@Mixin(Entity.class)
public class EntityMixin implements TransformerSource {
    @WrapMethod(method = "distanceTo")
    private float toroidal$distanceThroughSeam(Entity other, Operation<Float> original) {
        WorldFold transformer = toroidal$wrappedTransformer();
        if (transformer == null) {
            return original.call(other);
        }

        return (float) Math.sqrt(toroidal$sqrTo(transformer, other.getX(), other.getY(), other.getZ()));
    }

    @WrapMethod(method = "distanceToSqr(DDD)D")
    private double toroidal$distanceToSqrThroughSeam(double x, double y, double z, Operation<Double> original) {
        WorldFold transformer = toroidal$wrappedTransformer();
        if (transformer == null) {
            return original.call(x, y, z);
        }

        return toroidal$sqrTo(transformer, x, y, z);
    }

    @WrapMethod(method = "distanceToSqr(Lnet/minecraft/world/phys/Vec3;)D")
    private double toroidal$distanceToSqrVecThroughSeam(Vec3 pos, Operation<Double> original) {
        WorldFold transformer = toroidal$wrappedTransformer();
        if (transformer == null) {
            return original.call(pos);
        }

        return toroidal$sqrTo(transformer, pos.x, pos.y, pos.z);
    }

    @WrapMethod(method = "closerThan(Lnet/minecraft/world/entity/Entity;D)Z")
    private boolean toroidal$closerThanThroughSeam(Entity other, double distance, Operation<Boolean> original) {
        WorldFold transformer = toroidal$wrappedTransformer();
        if (transformer == null) {
            return original.call(other, distance);
        }

        return toroidal$sqrTo(transformer, other.getX(), other.getY(), other.getZ()) < Mth.square(distance);
    }

    @WrapMethod(method = "closerThan(Lnet/minecraft/world/entity/Entity;DD)Z")
    private boolean toroidal$closerThanXZThroughSeam(Entity other, double distanceXZ, double distanceY,
            Operation<Boolean> original) {
        WorldFold transformer = toroidal$wrappedTransformer();
        if (transformer == null) {
            return original.call(other, distanceXZ, distanceY);
        }

        Entity self = (Entity) (Object) this;
        Vec3 delta = transformer.foldDelta(self.position(), other.position());
        return Mth.lengthSquared(delta.x, delta.z) < Mth.square(distanceXZ)
                && Mth.square(delta.y) < Mth.square(distanceY);
    }

    @ModifyVariable(method = "lookAt(Lnet/minecraft/commands/arguments/EntityAnchorArgument$Anchor;Lnet/minecraft/world/phys/Vec3;)V",
            at = @At("HEAD"), argsOnly = true)
    private Vec3 toroidal$lookAtNearestCopy(Vec3 pos) {
        return SeamSteering.nearestCopy((Entity) (Object) this, pos);
    }

    @ModifyVariable(method = "push(Lnet/minecraft/world/entity/Entity;)V", at = @At("STORE"), ordinal = 0)
    private double toroidal$pushDeltaX(double deltaX) {
        return SeamAim.foldX((Entity) (Object) this, deltaX);
    }

    @ModifyVariable(method = "push(Lnet/minecraft/world/entity/Entity;)V", at = @At("STORE"), ordinal = 1)
    private double toroidal$pushDeltaZ(double deltaZ) {
        return SeamAim.foldZ((Entity) (Object) this, deltaZ);
    }

    @ModifyArg(
            method = "applyEffectsFromBlocks()V",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/world/entity/Entity$Movement;<init>(Lnet/minecraft/world/phys/Vec3;Lnet/minecraft/world/phys/Vec3;)V"),
            index = 0)
    private Vec3 toroidal$foldBridgeThroughSeam(Vec3 from) {
        WorldFold transformer = toroidal$wrappedTransformer();
        Vec3 position = ((Entity) (Object) this).position();
        return NearestCopy.toward(transformer, position, from);
    }

    @ModifyArg(
            method = "getRelativePortalPosition",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/world/level/portal/PortalShape;getRelativePosition(Lnet/minecraft/util/BlockUtil$FoundRectangle;Lnet/minecraft/core/Direction$Axis;Lnet/minecraft/world/phys/Vec3;Lnet/minecraft/world/entity/EntityDimensions;)Lnet/minecraft/world/phys/Vec3;"),
            index = 2)
    private Vec3 toroidal$portalPositionNearestCorner(Vec3 position, @Local(argsOnly = true) BlockUtil.FoundRectangle portalArea) {
        WorldFold transformer = toroidal$wrappedTransformer();
        return NearestCopy.toward(transformer, Vec3.atLowerCornerOf(portalArea.minCorner), position);
    }

    @WrapOperation(
            method = "checkSupportingBlock",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/world/level/Level;findSupportingBlock(Lnet/minecraft/world/entity/Entity;Lnet/minecraft/world/phys/AABB;)Ljava/util/Optional;"))
    private Optional<BlockPos> toroidal$storeCanonicalSupportingBlock(Level level, Entity source, AABB box,
            Operation<Optional<BlockPos>> original) {
        Optional<BlockPos> found = original.call(level, source, box);
        if (found.isEmpty()) {
            return found;
        }

        BlockPos raw = found.get();
        BlockPos folded = WorldLoopAttachments.transformerOf(level).fold(raw);
        return folded == raw ? found : Optional.of(folded);
    }

    @ModifyReturnValue(method = "getOnPos(F)Lnet/minecraft/core/BlockPos;", at = @At("RETURN"))
    private BlockPos toroidal$canonicalOnPos(BlockPos raw) {
        return WorldLoopAttachments.transformerOf(((Entity) (Object) this).level()).fold(raw);
    }

    @Inject(method = "snapTo(DDDFF)V", at = @At("TAIL"))
    private void toroidal$followPlayerPlacement(double x, double y, double z, float yRot, float xRot, CallbackInfo ci) {
        if ((Object) this instanceof ServerPlayer player) {
            ClientPosition.rebase(player);
            CircumnavigationTracker.sample(player);
        }
    }

    @Inject(
            method = "teleportSetPosition(Lnet/minecraft/world/entity/PositionMoveRotation;"
                    + "Lnet/minecraft/world/entity/PositionMoveRotation;Ljava/util/Set;)V",
            at = @At("TAIL"))
    private void toroidal$sampleTravelOnTeleport(PositionMoveRotation currentValues, PositionMoveRotation destination,
            Set<Relative> relatives, CallbackInfo ci) {
        if ((Object) this instanceof ServerPlayer player) {
            CircumnavigationTracker.sample(player);
        }
    }

    @Inject(method = "removeVehicle", at = @At("HEAD"))
    private void toroidal$resyncVehicleOnDismount(CallbackInfo ci) {
        VehicleDismountResync.resyncAfterDismount((Entity) (Object) this);
    }

    @Unique
    private @Nullable Level toroidal$transformerLevel;

    @Unique
    private WorldFold toroidal$transformer;

    @Override
    public @Nullable WorldFold toroidal$wrappedTransformer() {
        Level level = ((Entity) (Object) this).level();
        if (level != this.toroidal$transformerLevel) {
            this.toroidal$transformer = WorldLoopAttachments.transformerOf(level);
            this.toroidal$transformerLevel = level;
        }

        WorldFold transformer = this.toroidal$transformer;
        return transformer.isWrapped() ? transformer : null;
    }

    @Unique
    private double toroidal$sqrTo(WorldFold transformer, double x, double y, double z) {
        Entity self = (Entity) (Object) this;
        return transformer.sqrDistance(self.getX(), self.getY(), self.getZ(), x, y, z);
    }
}
