package com.toroidalworld.mixin;

import java.util.Set;

import org.jspecify.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

import com.toroidalworld.InjectionTargets;
import com.toroidalworld.accessors.NavigationShifter;
import com.toroidalworld.accessors.TransformerSource;
import com.toroidalworld.core.WorldFold;
import com.toroidalworld.engine.fold.FoldedCopies;
import com.toroidalworld.engine.fold.SeamDelta;
import com.toroidalworld.engine.seam.SeamRange;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Position;
import net.minecraft.core.Vec3i;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.navigation.PathNavigation;
import net.minecraft.world.level.pathfinder.Path;
import net.minecraft.world.phys.Vec3;

@Mixin(PathNavigation.class)
public class PathNavigationMixin implements NavigationShifter {
    @Shadow
    @Final
    protected Mob mob;

    @Shadow
    protected @Nullable Path path;

    @Shadow
    private @Nullable BlockPos targetPos;

    @Shadow
    protected Vec3i timeoutCachedNode;

    @Shadow
    protected Vec3 lastStuckCheckPos;

    @ModifyVariable(
            method = "createPath(Ljava/util/Set;IZIF)Lnet/minecraft/world/level/pathfinder/Path;",
            at = @At("HEAD"), argsOnly = true)
    private Set<BlockPos> toroidal$targetsThroughSeam(Set<BlockPos> targets) {
        WorldFold transformer = toroidal$wrappedTransformer();
        if (transformer == null || targets.isEmpty()) {
            return targets;
        }

        BlockPos from = this.mob.blockPosition();
        return FoldedCopies.of(targets, target -> transformer.nearestCopy(from, target));
    }

    @WrapOperation(
            method = "followThePath",
            at = @At(value = "INVOKE", target = "Ljava/lang/Math;abs(D)D", ordinal = 0))
    private double toroidal$nodeDistanceX(double delta, Operation<Double> original) {
        WorldFold transformer = toroidal$wrappedTransformer();
        return transformer == null ? original.call(delta) : Math.abs(SeamDelta.foldX(transformer, delta));
    }

    @WrapOperation(
            method = "followThePath",
            at = @At(value = "INVOKE", target = "Ljava/lang/Math;abs(D)D", ordinal = 2))
    private double toroidal$nodeDistanceZ(double delta, Operation<Double> original) {
        WorldFold transformer = toroidal$wrappedTransformer();
        return transformer == null ? original.call(delta) : Math.abs(SeamDelta.foldZ(transformer, delta));
    }

    @WrapOperation(
            method = "shouldRecomputePath",
            at = @At(value = "INVOKE",
                    target = InjectionTargets.BLOCK_POS_CLOSER_TO_CENTER_THAN))
    private boolean toroidal$replanRangeThroughSeam(BlockPos changedPos, Position middlePos, double distance,
            Operation<Boolean> original) {
        return SeamRange.closerToCenterThan(this.mob, changedPos, middlePos, distance);
    }

    @Override
    public void toroidal$shiftBy(int shiftX, int shiftZ) {
        if (this.targetPos != null) {
            this.targetPos = this.targetPos.offset(shiftX, 0, shiftZ);
        }

        this.lastStuckCheckPos = this.lastStuckCheckPos.add(shiftX, 0, shiftZ);
        if (!Vec3i.ZERO.equals(this.timeoutCachedNode)) {
            this.timeoutCachedNode = this.timeoutCachedNode.offset(shiftX, 0, shiftZ);
        }

        if (this.path != null && !this.path.isDone()) {
            ((NavigationShifter) (Object) this.path).toroidal$shiftBy(shiftX, shiftZ);
        }
    }

    @Unique
    private @Nullable WorldFold toroidal$wrappedTransformer() {
        return ((TransformerSource) this.mob).toroidal$wrappedTransformer();
    }
}
