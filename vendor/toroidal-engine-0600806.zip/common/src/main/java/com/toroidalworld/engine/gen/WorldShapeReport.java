package com.toroidalworld.engine.gen;

import java.util.ArrayList;
import java.util.List;

import org.jspecify.annotations.Nullable;

import com.toroidalworld.ToroidalWorld;
import com.toroidalworld.core.CarriedShape;
import com.toroidalworld.core.CoordinateConstants;
import com.toroidalworld.core.FlatShape;
import com.toroidalworld.core.ShapedChunkGenerator;
import com.toroidalworld.core.WorldLoopBounds;
import com.toroidalworld.core.WorldLoopBounds.AxisBounds;
import com.toroidalworld.core.WorldLoopSizes;
import com.toroidalworld.engine.gen.DatapackStemOverrides.StemOverride;
import com.toroidalworld.platform.Platforms;

import net.minecraft.SharedConstants;
import net.minecraft.core.Direction;
import net.minecraft.core.registries.Registries;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.chunk.ChunkGenerator;

public final class WorldShapeReport {
    private static final String CODEC_SOURCE = "codec";
    private static final String STAMP_SOURCE = "stamp";
    private static final String RESTORED_SOURCE = "restored";
    private static final String STORED_SOURCE = "stored";
    private static final String NOT_PERIODIC_NOTE = ", stamped, terrain not periodic";

    public record Line(boolean broken, String text) {
    }

    record Note(boolean broken, String text) {
        static final Note NONE = new Note(false, "");
    }

    public static List<Line> lines(MinecraftServer server) {
        FlatShape overworldShape = shapeOf(server.overworld());
        if (overworldShape == null) {
            return List.of();
        }

        List<Line> lines = new ArrayList<>();
        for (ServerLevel level : server.getAllLevels()) {
            FlatShape shape = shapeOf(level);
            if (shape != null) {
                lines.add(wrappedLine(server, level, shape));
            } else {
                lines.add(new Line(false, unwrappedLine(server, level, overworldShape)));
            }
        }

        return lines;
    }

    private static Line wrappedLine(MinecraftServer server, ServerLevel level, FlatShape shape) {
        WorldLoopBounds bounds = shape.bounds();
        StemOverride override = overrideOf(level);
        ChunkGenerator generator = level.getChunkSource().getGenerator();
        Note netherScale = netherScale(server, level, bounds);
        Note endWidth = endWidth(level, bounds);
        return new Line(netherScale.broken() || endWidth.broken(), "World shape: " + level.dimension().identifier()
                + " generator=" + generatorId(generator)
                + " shape=" + shapeSource(level, override)
                + " identification=" + shape.identification()
                + " x=" + bounds.x().spanText() + " z=" + bounds.z().spanText() + " chunks"
                + ", " + widths(bounds)
                + seamTerrain(generator)
                + netherScale.text()
                + endWidth.text()
                + datapackOverride(override)
                + tail());
    }

    private static String unwrappedLine(MinecraftServer server, ServerLevel level, FlatShape overworldShape) {
        double overworldScale = server.overworld().dimensionType().coordinateScale();
        double scale = level.dimensionType().coordinateScale();
        FlatShape derived = ShapedDimensions.derivedShape(overworldShape, overworldScale, scale);
        String reason = derived == null
                ? "coordinate scale " + scale + " derives no whole-chunk width in range from the overworld's "
                        + widths(overworldShape.bounds())
                : "a derivable " + widths(derived.bounds()) + " never reached the generator";
        return "World shape: " + level.dimension().identifier() + " not wrapped"
                + " generator=" + generatorId(level.getChunkSource().getGenerator())
                + ", " + reason
                + tail();
    }

    private static String seamTerrain(ChunkGenerator generator) {
        return ShapedChunkGenerator.tilesAtSeam(generator) ? "" : NOT_PERIODIC_NOTE;
    }

    private static String shapeSource(ServerLevel level, @Nullable StemOverride override) {
        if (override != null) {
            return switch (override.outcome()) {
                case RESHAPED -> RESTORED_SOURCE;
                case STAMPED -> STAMP_SOURCE;
                case REFUSED -> STORED_SOURCE;
            };
        }

        return level.getChunkSource().getGenerator() instanceof ShapedChunkGenerator ? CODEC_SOURCE : STAMP_SOURCE;
    }

    private static @Nullable StemOverride overrideOf(ServerLevel level) {
        return DatapackStemOverrides.of(Registries.levelToLevelStem(level.dimension()));
    }

    private static String datapackOverride(@Nullable StemOverride override) {
        if (override == null) {
            return "";
        }

        return ", a datapack " + override.datapackGenerator() + " " + switch (override.outcome()) {
            case RESHAPED -> "took the stored shape";
            case STAMPED -> "was stamped with the stored shape";
            case REFUSED -> "was refused the stored shape";
        };
    }

    private static String tail() {
        return " | mod=" + Platforms.get().modVersion()
                + " mc=" + SharedConstants.getCurrentVersion().name()
                + " loader=" + Platforms.get().loaderName() + " " + Platforms.get().loaderVersion();
    }

    private static @Nullable FlatShape shapeOf(@Nullable ServerLevel level) {
        CarriedShape carried = level == null ? null : ShapedChunkGenerator.carriedShapeOf(level);
        return carried == null ? null : carried.shape();
    }

    private static String generatorId(ChunkGenerator generator) {
        return switch (generator) {
            case LoopedFlatChunkGenerator flat -> ToroidalWorld.MODID + ":" + WorldLoopGenerators.TOROIDAL_FLAT_ID;
            case LoopedChunkGenerator looped -> ToroidalWorld.MODID + ":" + WorldLoopGenerators.TOROIDAL_ID;
            default -> generator.getClass().getSimpleName();
        };
    }

    private static String widths(WorldLoopBounds bounds) {
        if (bounds.isSquare()) {
            return "width " + WorldLoopSizes.describe(bounds.chunkWidth(Direction.Axis.X));
        }

        StringBuilder widths = new StringBuilder("width");
        if (bounds.x() instanceof AxisBounds.Looped xLooped) {
            widths.append(" x=").append(WorldLoopSizes.describe(xLooped.chunkWidth()));
        }

        if (bounds.z() instanceof AxisBounds.Looped zLooped) {
            widths.append(" z=").append(WorldLoopSizes.describe(zLooped.chunkWidth()));
        }

        return widths.toString();
    }

    private static Note netherScale(MinecraftServer server, ServerLevel level, WorldLoopBounds bounds) {
        if (level.dimension() != Level.NETHER) {
            return Note.NONE;
        }

        FlatShape overworldShape = shapeOf(server.overworld());
        return overworldShape == null ? Note.NONE : netherScaleNote(overworldShape.bounds(), bounds);
    }

    static Note netherScaleNote(WorldLoopBounds overworld, WorldLoopBounds nether) {
        for (Direction.Axis axis : CoordinateConstants.HORIZONTAL_AXES) {
            if (sharedLoop(overworld, nether, axis)
                    && overworld.chunkWidth(axis) % nether.chunkWidth(axis) != 0) {
                return new Note(true, ", BROKEN portal scale on the " + axis.getName() + " axis: an overworld of "
                        + WorldLoopSizes.describe(overworld.chunkWidth(axis)) + " does not divide by a nether of "
                        + WorldLoopSizes.describe(nether.chunkWidth(axis))
                        + ", so portals will not line up across the seam");
            }
        }

        for (Direction.Axis axis : CoordinateConstants.HORIZONTAL_AXES) {
            if (sharedLoop(overworld, nether, axis)) {
                return new Note(false, ", scale 1:" + overworld.chunkWidth(axis) / nether.chunkWidth(axis));
            }
        }

        return Note.NONE;
    }

    private static Note endWidth(ServerLevel level, WorldLoopBounds bounds) {
        return level.dimension() != Level.END ? Note.NONE : endWidthNote(bounds);
    }

    static Note endWidthNote(WorldLoopBounds end) {
        for (Direction.Axis axis : CoordinateConstants.HORIZONTAL_AXES) {
            if (end.loops(axis) && end.chunkWidth(axis) < WorldLoopSizes.END_MIN_CHUNK_WIDTH) {
                return new Note(true, ", BROKEN End width on the " + axis.getName() + " axis: "
                        + WorldLoopSizes.describe(end.chunkWidth(axis)) + " is under the "
                        + WorldLoopSizes.describe(WorldLoopSizes.END_MIN_CHUNK_WIDTH)
                        + " the outer islands need, so no end cities and no elytra");
            }
        }

        return Note.NONE;
    }

    private static boolean sharedLoop(WorldLoopBounds overworld, WorldLoopBounds nether, Direction.Axis axis) {
        return overworld.loops(axis) && nether.loops(axis);
    }

    private WorldShapeReport() {
    }
}
