package com.toroidalworld.client.shape.torus;

import java.util.function.Consumer;

import org.jspecify.annotations.Nullable;

import com.toroidalworld.client.shape.LoopSettingsScreen;
import com.toroidalworld.client.shape.LoopSizeControls;
import com.toroidalworld.api.v1.shape.LoopSpans;
import com.toroidalworld.shape.torus.TorusSettings;

import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;

public class TorusSettingsScreen extends LoopSettingsScreen<TorusSettings> {
    private static final Component TITLE = Component.translatable("gui.toroidal_world.toroidal_settings.title");

    public TorusSettingsScreen(Screen parent, TorusSettings current, Consumer<TorusSettings> onDone) {
        super(TITLE, parent, onChange -> LoopSizeControls.perAxis(current.chunkWidth(Direction.Axis.X),
                current.chunkWidth(Direction.Axis.Z), current.netherScale(), current.endChunkWidth(), onChange),
                current.generationOptions(), TorusSettings.OFFERED_OPTIONS, onDone);
    }

    @Override
    protected TorusSettings build() {
        return new TorusSettings(
                LoopSpans.ofWidths(this.controls.effectiveSize(Direction.Axis.X),
                        this.controls.effectiveSize(Direction.Axis.Z)),
                this.controls.netherScale(),
                LoopSpans.ofWidth(this.controls.effectiveEndSize()),
                this.committedOptions());
    }

    @Override
    protected OptionContext newOptionContext() {
        return new ScreenContext();
    }

    private final class ScreenContext extends OptionContext {
        @Override
        public @Nullable Integer loopChunkWidth() {
            Integer xChunkWidth = this.loopChunkWidth(Direction.Axis.X);
            Integer zChunkWidth = this.loopChunkWidth(Direction.Axis.Z);
            return xChunkWidth == null || zChunkWidth == null ? null : Math.min(xChunkWidth, zChunkWidth);
        }

        @Override
        public @Nullable Integer loopChunkWidth(Direction.Axis axis) {
            return TorusSettingsScreen.this.controls.effectiveSize(axis);
        }
    }
}
