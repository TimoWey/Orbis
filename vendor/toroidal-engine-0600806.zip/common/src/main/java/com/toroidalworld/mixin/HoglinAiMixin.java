package com.toroidalworld.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

import com.toroidalworld.InjectionTargets;
import com.toroidalworld.engine.seam.SeamRange;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Vec3i;
import net.minecraft.world.entity.monster.hoglin.Hoglin;
import net.minecraft.world.entity.monster.hoglin.HoglinAi;

@Mixin(HoglinAi.class)
public class HoglinAiMixin {
    @WrapOperation(method = "isPosNearNearestRepellent",
            at = @At(value = "INVOKE", target = InjectionTargets.BLOCK_POS_CLOSER_THAN))
    private static boolean toroidal$repellentReachThroughSeam(BlockPos repellent, Vec3i candidate, double distance,
            Operation<Boolean> original, @Local(argsOnly = true) Hoglin body) {
        return SeamRange.closerThan(body, repellent, candidate, distance);
    }
}
